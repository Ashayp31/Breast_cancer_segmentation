import tensorflow as tf
msg = tf.constant('TensorFlow 2 Hello World')
tf.print(msg)
